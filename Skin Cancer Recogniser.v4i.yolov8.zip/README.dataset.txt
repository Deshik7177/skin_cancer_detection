# Skin Cancer Recogniser > 2025-09-03 11:13am
https://universe.roboflow.com/ai-eds7n/skin-cancer-recogniser

Provided by a Roboflow user
License: CC BY 4.0

